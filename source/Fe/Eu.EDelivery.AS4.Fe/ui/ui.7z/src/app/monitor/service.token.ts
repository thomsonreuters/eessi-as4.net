import { OpaqueToken } from '@angular/core';

export const MESSAGESERVICETOKEN = new OpaqueToken('MESSAGESERVICE');
