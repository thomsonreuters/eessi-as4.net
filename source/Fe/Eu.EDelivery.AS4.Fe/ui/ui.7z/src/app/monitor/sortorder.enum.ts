export enum SortOrder {
    descending,
    ascending
}