/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

export class PartyId {
	id: string;
	type: string;

	static FIELD_id: string = 'id';	
	static FIELD_type: string = 'type';		
}
