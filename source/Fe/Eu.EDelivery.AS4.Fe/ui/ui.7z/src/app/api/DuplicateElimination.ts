/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

export class DuplicateElimination {
	isEnabled: boolean;

	static FIELD_isEnabled: string = 'isEnabled';	
}
