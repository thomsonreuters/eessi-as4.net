/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

export class SigningVerification {
	signature: number;

	static FIELD_signature: string = 'signature';	
}
