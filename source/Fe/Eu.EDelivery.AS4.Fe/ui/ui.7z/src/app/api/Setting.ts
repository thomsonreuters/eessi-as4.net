/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

export class Setting {
	key: string;
	value: string;

	static FIELD_key: string = 'key';	
	static FIELD_value: string = 'value';	
}
