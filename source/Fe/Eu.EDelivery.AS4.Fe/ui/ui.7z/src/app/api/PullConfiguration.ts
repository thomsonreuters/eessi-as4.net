/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

export class PullConfiguration {
	subChannel: string;

	static FIELD_subChannel: string = 'subChannel';
}
