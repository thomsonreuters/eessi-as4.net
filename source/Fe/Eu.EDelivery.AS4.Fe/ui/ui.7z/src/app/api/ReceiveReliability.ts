/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { DuplicateElimination } from "./DuplicateElimination";

export class ReceiveReliability {
	duplicateElimination: DuplicateElimination;

	static FIELD_duplicateElimination: string = 'duplicateElimination';
}
