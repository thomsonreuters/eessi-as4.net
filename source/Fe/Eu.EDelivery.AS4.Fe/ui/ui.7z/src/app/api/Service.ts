/* tslint:disable */
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

export class Service {
	value: string;
	type: string;

	static FIELD_value: string = 'value';
	static FIELD_type: string = 'type';	
}
